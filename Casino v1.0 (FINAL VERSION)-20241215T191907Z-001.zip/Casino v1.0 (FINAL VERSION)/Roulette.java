import java.util.*;

public class Roulette
{
    private Wallet yourWallet;

    private int wager;

    public Roulette()
    {
        yourWallet = new Wallet();

        wager = 0;
    }

    public Wallet playRoulette(Wallet wallet)
    {
        Scanner sc = new Scanner(System.in);

        int running = 0;

        yourWallet = wallet;
        System.out.println("Welcome to Roulette!\n" + yourWallet);
        while (running == 0) {
            int num = (int)(36*Math.random());

            System.out.println("How much would you like to wager?");
            wager = sc.nextInt();
            String sadsacrifice = sc.nextLine();

            System.out.println("Will you put your money on [RED], [BLACK], or [GREEN]?\n");

            String bet = sc.nextLine();
            bet = bet.toUpperCase();

            System.out.print("Spinning the wheel");
            try{
                Thread.sleep(500);
            }
            catch (InterruptedException e) {
                System.out.println("A problem occured\n");
            }
            System.out.print(".");
            try{
                Thread.sleep(500);
            }
            catch (InterruptedException e) {
                System.out.println("A problem occured\n");
            }
            System.out.print(".");
            try{
                Thread.sleep(500);
            }
            catch (InterruptedException e) {
                System.out.println("A problem occured\n");
            }
            System.out.println(".");
            try{
                Thread.sleep(2000);
            }
            catch (InterruptedException e) {
                System.out.println("A problem occured\n");
            }

            while(true)
            {
                if (bet.equals("GREEN") ) {
                    if (num == 0) {
                        System.out.println("Congragulations, the ball landed on Green. The payout is 250:1\n");

                        yourWallet.changeMoney(wager*250);
                    }
                    else {
                        System.out.println("Sorry, the ball didn't land on green. This bet is a special case, and you unfortunately lose 35x your wager!");

                        yourWallet.changeMoney(-(wager*35));
                    }
                    break;
                }
                else if (bet.equals("RED") ) {
                    if (num%2 == 0) {
                        System.out.println("Congragulations, the ball landed on Red. You won your wager back\n");

                        yourWallet.changeMoney(wager);
                    }
                    else {
                        System.out.println("Sorry, you lost your wager");

                        yourWallet.changeMoney(-wager);
                    }

                    break;
                }
                else if (bet.equals("BLACK") ) {
                    if (num%2 != 0) {
                        System.out.println("Congragulations, the ball landed on Black. You won your wager back\n");

                        yourWallet.changeMoney(wager);
                    }
                    else {
                        System.out.println("Sorry, you lost your wager");

                        yourWallet.changeMoney(-wager);
                    }
                    break;
                }
                else {
                    System.out.println("Please try again. \n Will you put your money on [RED], [BLACK], or [GREEN]?\n");

                    bet = sc.nextLine();

                    bet = bet.toUpperCase();
                }
            }

            System.out.println(yourWallet);

            if ( yourWallet.getWallet() <= 0 )
            {
                System.out.println("NO MO MONEY!");
                break;
            }

            System.out.println("Would you like to play again? [YES] [NO]\n");

            String ans = sc.nextLine();

            ans = ans.toUpperCase();
            int typo = 0;
            while (typo == 0) {
                if ( ans.equals("YES") ) {
                    running = 0;
                    typo = 1;

                    System.out.println("-----------------------------------------");
                }
                else if( ans.equals("NO") ) {
                    running = 1;
                    typo = 1;
                }
                else {
                    System.out.println("Please try again. [YES] [NO]\n");
                    ans = sc.nextLine();

                    ans = ans.toUpperCase();
                }
            }
        }

        return yourWallet;
    }
}

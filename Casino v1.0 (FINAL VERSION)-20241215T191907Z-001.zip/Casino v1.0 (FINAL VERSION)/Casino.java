import java.util.*;

public class Casino
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);

        int go = 0;

        BlackJack test = new BlackJack();

        Poker tests = new Poker();

        Roulette testss = new Roulette();

        Wallet yourWallet = new Wallet();

        System.out.println("Welcome to the Casino!\n" + yourWallet);
        while (go == 0) //main loop
        {
            if ( yourWallet.getWallet() <= 0 )
            {
                System.out.println("Keep the change ya filthy animal! Come back when you aren't poorer than Patrick Star!");
                break;
            }
            System.out.println("-----------------------------------------");
            System.out.println("Would you like to play [Blackjack],[Poker],[Roulette], or [Exit] the Casino");

            String c = sc.nextLine();

            c = c.toUpperCase();
            while(true) {
                if ( c.equals("EXIT") ) {
                    
                    System.out.println("-----------------------------------------");
                    System.out.println("Thank you for visiting! You leave the casino with $" + yourWallet.getWallet());
                    go = 1;
                    break;
                }
                else if ( c.equals("BLACKJACK") ) {
                    
                    System.out.println("-----------------------------------------");
                    yourWallet = test.playBlackjack(yourWallet);
                    System.out.println("Thanks for playing Blackjack!\n");
                    break;
                }
                else if (c.equals("POKER") ) {
                    
                    System.out.println("-----------------------------------------");
                    yourWallet = tests.playPoker(yourWallet);
                    System.out.println("Thanks for playing Poker!\n");
                    break;
                }
                else if (c.equals("ROULETTE") ) {
                    
                    System.out.println("-----------------------------------------");
                    yourWallet = testss.playRoulette(yourWallet);
                    System.out.println("Thanks for playing Roulette!\n");
                    break;
                }
                else {
                    System.out.println("Please try again.  [Blackjack],[Poker],[Roulette], or [Exit] the Casino\n");
                    c = sc.nextLine();
                    c = c.toUpperCase();
                }
            }

        }
    }

}

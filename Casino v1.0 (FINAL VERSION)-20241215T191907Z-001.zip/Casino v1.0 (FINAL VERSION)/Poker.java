import java.util.*;

public class Poker
{
    private ArrayList<Card> playerHand;

    private Wallet yourWallet;
    private int wager;

    public Poker()
    {
        playerHand = new ArrayList<Card>();
        yourWallet = new Wallet();
    }

    public Wallet playPoker(Wallet wallet)
    {
        Scanner sc = new Scanner(System.in);
        
        yourWallet = wallet;
        
        System.out.println("Welcome to Poker!\n" + yourWallet);
        
        int running = 0;

        Deck d = new Deck();
        d.shuffleDeck();

        while (running == 0)
        {
            playerHand = new ArrayList<Card>();
            wager = 0;

            if (d.size() < 20) {
                System.out.println("Reshuffling the deck... \n");
                d = new Deck();
                d.shuffleDeck();

                try{
                    Thread.sleep(2000);
                }
                catch (InterruptedException e) {
                    System.out.println("Reshuffle interrupted! \n");
                }
            }

            for (int i = 0; i < 5; i++) 
            {
                playerHand.add(d.playCard());
            }

            System.out.println("How much would you like to wager?");
            wager = sc.nextInt();
            String MORESACRIFICES = sc.nextLine();
            ArrayList<Card> temp = new ArrayList<Card>();
            System.out.println(playerHand + "\n This is your hand \n");
            int tre = 0;

            //start switching process

            while (tre == 0) {

                System.out.println(playerHand.get(0) + "\n Would you like to change this card?[YES][NO] \n");
                String choice = sc.nextLine();

                choice = choice.toUpperCase();

                if (choice.equals("YES") ) {
                    temp.add(d.playCard()); 
                    break;
                }
                else if (choice.equals("NO") ) {
                    temp.add(playerHand.get(0));
                    break;
                }
            }
            while (tre == 0) {

                System.out.println(playerHand.get(1) + "\n Would you like to change this card?[YES][NO]\n");
                String choice = sc.nextLine();

                choice = choice.toUpperCase();

                if (choice.equals("YES") ) {
                    temp.add(d.playCard()); 
                    break;
                }
                else if (choice.equals("NO") ) {
                    temp.add(playerHand.get(1));
                    break;
                }
            }
            while (tre == 0) {

                System.out.println(playerHand.get(2) + "\n Would you like to change this card?[YES][NO]\n");
                String choice = sc.nextLine();

                choice = choice.toUpperCase();

                if (choice.equals("YES") ) {
                    temp.add(d.playCard()); 
                    break;
                }
                else if (choice.equals("NO") ) {
                    temp.add(playerHand.get(2));
                    break;
                }
            }
            while (tre == 0) {

                System.out.println(playerHand.get(3) + "\n Would you like to change this card?[YES][NO]\n");
                String choice = sc.nextLine();

                choice = choice.toUpperCase();

                if (choice.equals("YES") ) {
                    temp.add(d.playCard()); 
                    break;
                }
                else if (choice.equals("NO") ) {
                    temp.add(playerHand.get(3));
                    break;
                }
            }
            while (tre == 0) {

                System.out.println(playerHand.get(4) + "\n Would you like to change this card?[YES][NO]\n");
                String choice = sc.nextLine();

                choice = choice.toUpperCase();

                if (choice.equals("YES") ) {
                    temp.add(d.playCard()); 
                    break;
                }
                else if (choice.equals("NO") ) {
                    temp.add(playerHand.get(4));
                    break;
                }
            }
            //end switching process 

            //sorting
            playerHand = temp;

            Card sac = new Card(0,"null");
            for (int i = 0; i < temp.size()-1; i++) {
                for (int j = 0; j < temp.size()-1; j++) {
                    if( temp.get(j).getValue() > temp.get(j+1).getValue() ) {
                        sac = temp.get(j);
                        temp.set(j,temp.get(j+1));
                        temp.set(j+1,sac);
                    }
                }
            }

            playerHand = temp;

            System.out.println("Getting your new hand!\n");

            try{
                Thread.sleep(2000);
            }
            catch (InterruptedException e) {
                System.out.println("A problem occured!\n");
            }

            
            System.out.println(playerHand);

            System.out.println("Calculating your earnings!\n");

            try{
                Thread.sleep(2000);
            }
            catch (InterruptedException e) {
                System.out.println("A problem occured!\n");
            }

            if(royalFlush() == true) {
                yourWallet.changeMoney(wager*250);

                System.out.println("Congragulations, you have a Royal Flush! Payout is 250:1");
            }
            else if(straightFlush() == true) {
                yourWallet.changeMoney(wager*50);

                System.out.println("Congragulations, you have a Straight Flush! Payout is 50:1");
            }
            else if(fourOfAKind() == true) {
                yourWallet.changeMoney(wager*25);

                System.out.println("Congragulations, you have a Four of a Kind! Payout is 25:1");
            }
            else if(fullHouse() == true) {
                yourWallet.changeMoney(wager*9);

                System.out.println("Congragulations, you have a Full House! Payout is 9:1");
            }
            else if(flush() == true) {
                yourWallet.changeMoney(wager*6);

                System.out.println("Congragulations, you have a Flush! Payout is 6:1");
            }
            else if(straight() == true) {
                yourWallet.changeMoney(wager*4);

                System.out.println("Congragulations, you have a Straight! Payout is 4:1");
            }
            else if(threeOfAKind() == true) {
                yourWallet.changeMoney(wager*3);

                System.out.println("Congragulations, you have a Three of a Kind! Payout is 3:1");
            }
            else if(twoPair() == true) {
                yourWallet.changeMoney(wager*2);

                System.out.println("Congragulations, you have Two Pairs! Payout is 2:1");
            }
            else if(pair() == true) {
                yourWallet.changeMoney(wager);

                System.out.println("Congragulations, you have a Pair! Payout is 1:1");
            }
            else {
                yourWallet.changeMoney(-wager);

                System.out.println("Your hand has no winning combinations! You lose your wager of $" + wager);
            }

            System.out.println(yourWallet);

            if ( yourWallet.getWallet() <= 0 )
            {
                System.out.println("NO MO MONEY!");
                break;
            }

            System.out.println("Would you like to play again? [YES] [NO]\n");

            String ans = sc.nextLine();

            ans = ans.toUpperCase();
            int typo = 0;
            while (typo == 0) {
                if ( ans.equals("YES") ) {
                    running = 0;
                    typo = 1;

                    System.out.println("-----------------------------------------");
                }
                else if( ans.equals("NO") ) {
                    running = 1;
                    typo = 1;
                }
                else {
                    System.out.println("Please try again. [YES] [NO]\n");
                    ans = sc.nextLine();

                    ans = ans.toUpperCase();
                }
            }
        }

        //runAllTests();

        return yourWallet;
    }

    //check win conditions

    public boolean royalFlush()
    {
        boolean hasRoyalFlush = false;

        if ( flush() == true && straight() == true && playerHand.get(0).getValue() == 10 && playerHand.get(4).getValue() == 14 ) {
            hasRoyalFlush = true;
        }

        return hasRoyalFlush;
    }

    public boolean straightFlush()
    {
        boolean hasStraightFlush = false;

        if (flush() == true && straight() == true) {
            hasStraightFlush = true;
        }

        return hasStraightFlush;
    }

    public boolean fourOfAKind() {
        boolean hasFourOfAKind = false;

        for (int i = 0; i < playerHand.size() - 3; i++) {
            if (playerHand.get(i).getValue() == playerHand.get(i + 1).getValue() &&
            playerHand.get(i).getValue() == playerHand.get(i + 2).getValue() &&
            playerHand.get(i).getValue() == playerHand.get(i + 3).getValue()) {
                hasFourOfAKind = true;
                break;
            }
        }
        return hasFourOfAKind;
    }

    public boolean fullHouse()
    {
        boolean hasFullHouse = false;

        int threeOfAKindValue = -1;

        boolean threeOfAKind = false;
        boolean pair = false;

        for (int i = 0; i < playerHand.size() - 2; i++)
        {
            if (playerHand.get(i).getValue() == playerHand.get(i + 1).getValue() &&
            playerHand.get(i).getValue() == playerHand.get(i + 2).getValue()) {
                threeOfAKind = true;

                threeOfAKindValue = playerHand.get(i).getValue();
                break;
            }
        }

        for (int i = 0; i < playerHand.size() - 1; i++) {
            if (playerHand.get(i).getValue() == playerHand.get(i + 1).getValue() && playerHand.get(i).getValue() != threeOfAKindValue) {
                pair = true;
                break;
            }
        }

        if (threeOfAKind == true && pair == true) {
            hasFullHouse = true;
        }

        return hasFullHouse;
    }

    public boolean flush()
    {
        boolean hasFlush = true;
        String suit = playerHand.get(0).getSuit();

        for (int i = 0; i < playerHand.size(); i++) {
            if (!playerHand.get(i).getSuit().equals(suit)) {
                hasFlush = false;
                break;
            }
        }

        return hasFlush;
    }

    public boolean straight()
    {
        boolean hasStraight = true;

        for (int i = 0; i < playerHand.size(); i++)
        {
            if (i == playerHand.size() - 1)
            {
                break;
            }
            else {
                if (playerHand.get(i).getValue() + 1 != playerHand.get(i+1).getValue() ) {
                    hasStraight = false;
                    break;
                }
            }
        }

        return hasStraight;
    }

    public boolean threeOfAKind() {
        boolean hasThreeOfAKind = false;

        for (int i = 0; i < playerHand.size() - 2; i++) {
            if (playerHand.get(i).getValue() == playerHand.get(i + 1).getValue() &&
            playerHand.get(i).getValue() == playerHand.get(i + 2).getValue()) {
                hasThreeOfAKind = true;
                break;
            }
        }
        return hasThreeOfAKind;
    }

    public boolean twoPair() {
        boolean hasTwoPair = false;
        int pairCount = 0;

        for (int i = 0; i < playerHand.size() - 1; i++) {
            if (playerHand.get(i).getValue() == playerHand.get(i + 1).getValue()) {
                pairCount++;
                i++; 
            }
        }

        if (pairCount == 2) {
            hasTwoPair = true;
        }
        return hasTwoPair;
    }

    public boolean pair() {
        boolean hasPair = false;
        for (int i = 0; i < playerHand.size() - 1; i++) {
            if (playerHand.get(i).getValue() == playerHand.get(i + 1).getValue()) {
                hasPair = true;
                break;
            }
        }
        return hasPair;
    }

    //test methods

    public void testRoyalFlush() {
        playerHand.clear();
        playerHand.add(new Card(10, "Hearts"));
        playerHand.add(new Card(11, "Hearts"));
        playerHand.add(new Card(12, "Hearts"));
        playerHand.add(new Card(13, "Hearts"));
        playerHand.add(new Card(14, "Hearts"));
        System.out.println("Testing hand: " + playerHand);
        System.out.println("Royal Flush: " + royalFlush());
    }

    public void testStraightFlush() {
        playerHand.clear();
        playerHand.add(new Card(5, "Clubs"));
        playerHand.add(new Card(6, "Clubs"));
        playerHand.add(new Card(7, "Clubs"));
        playerHand.add(new Card(8, "Clubs"));
        playerHand.add(new Card(9, "Clubs"));
        System.out.println("Testing hand: " + playerHand);
        System.out.println("Straight Flush: " + straightFlush());
    }

    public void testFourOfAKind() {
        playerHand.clear();
        playerHand.add(new Card(7, "Diamonds"));
        playerHand.add(new Card(7, "Hearts"));
        playerHand.add(new Card(7, "Spades"));
        playerHand.add(new Card(7, "Clubs"));
        playerHand.add(new Card(2, "Hearts"));
        System.out.println("Testing hand: " + playerHand);
        System.out.println("Four of a Kind: " + fourOfAKind());
    }

    public void testFullHouse() {
        playerHand.clear();
        playerHand.add(new Card(4, "Hearts"));
        playerHand.add(new Card(4, "Diamonds"));
        playerHand.add(new Card(4, "Clubs"));
        playerHand.add(new Card(9, "Spades"));
        playerHand.add(new Card(9, "Hearts"));
        System.out.println("Testing hand: " + playerHand);
        System.out.println("Full House: " + fullHouse());
    }

    public void testFlush() {
        playerHand.clear();
        playerHand.add(new Card(2, "Spades"));
        playerHand.add(new Card(5, "Spades"));
        playerHand.add(new Card(8, "Spades"));
        playerHand.add(new Card(11, "Spades"));
        playerHand.add(new Card(14, "Spades"));
        System.out.println("Testing hand: " + playerHand);
        System.out.println("Flush: " + flush());
    }

    public void testStraight() {
        playerHand.clear();
        playerHand.add(new Card(3, "Diamonds"));
        playerHand.add(new Card(4, "Hearts"));
        playerHand.add(new Card(5, "Spades"));
        playerHand.add(new Card(6, "Clubs"));
        playerHand.add(new Card(7, "Diamonds"));
        System.out.println("Testing hand: " + playerHand);
        System.out.println("Straight: " + straight());
    }

    public void testThreeOfAKind() {
        playerHand.clear();
        playerHand.add(new Card(8, "Diamonds"));
        playerHand.add(new Card(8, "Hearts"));
        playerHand.add(new Card(8, "Clubs"));
        playerHand.add(new Card(3, "Spades"));
        playerHand.add(new Card(5, "Hearts"));
        System.out.println("Testing hand: " + playerHand);
        System.out.println("Three of a Kind: " + threeOfAKind());
    }

    public void testTwoPair() {
        playerHand.clear();
        playerHand.add(new Card(6, "Hearts"));
        playerHand.add(new Card(6, "Diamonds"));
        playerHand.add(new Card(9, "Clubs"));
        playerHand.add(new Card(9, "Spades"));
        playerHand.add(new Card(2, "Hearts"));
        System.out.println("Testing hand: " + playerHand);
        System.out.println("Two Pair: " + twoPair());
    }

    public void testPair() {
        playerHand.clear();
        playerHand.add(new Card(10, "Clubs"));
        playerHand.add(new Card(10, "Hearts"));
        playerHand.add(new Card(3, "Spades"));
        playerHand.add(new Card(7, "Diamonds"));
        playerHand.add(new Card(2, "Clubs"));
        System.out.println("Testing hand: " + playerHand);
        System.out.println("Pair: " + pair());
    }

    public void runAllTests() {
        testRoyalFlush();
        testStraightFlush();
        testFourOfAKind();
        testFullHouse();
        testFlush();
        testStraight();
        testThreeOfAKind();
        testTwoPair();
        testPair();
    }

}

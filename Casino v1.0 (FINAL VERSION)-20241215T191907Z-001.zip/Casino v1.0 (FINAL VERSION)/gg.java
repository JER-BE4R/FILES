
import java.util.*;

public class gg
{
    public static void main(String[] args)
    {
        
        //THIS IS A CLASS FOR TESTING BEFORE IMPLEMENTING INTO CASINO/BECAUSE I DONT WANT TO MESS UP CASINO
        
        BlackJack test = new BlackJack();
        Wallet yourWallet = new Wallet();
        //test.playBlackjack(yourWallet);
        
        //test.testAce();
        
        //Poker tests = new Poker();
        
        //tests.runAllTests();
        
        Roulette tests = new Roulette();
        
        tests.playRoulette(yourWallet);
        
        
    }
}
